# AMAÂLEM — Application Flutter

Plateforme marocaine d'artisans à la demande (modèle inDrive/Uber).

## Structure du projet

```
lib/
├── main.dart                    # Point d'entrée
├── core/theme/app_theme.dart    # Thème Dark Navy + Zellige Gold
├── models/                      # Modèles de données
│   ├── user_model.dart
│   ├── artisan_model.dart
│   ├── request_model.dart
│   ├── offer_model.dart
│   ├── booking_model.dart
│   └── review_model.dart
├── services/                    # Services Firebase
│   ├── auth_service.dart
│   ├── firestore_service.dart
│   ├── geolocation_service.dart
│   └── notification_service.dart
├── providers/
│   └── auth_provider.dart       # Riverpod state
└── screens/
    ├── auth/phone_auth_screen.dart
    ├── client/client_home_screen.dart
    └── artisan/artisan_home_screen.dart
firebase/
├── firestore.rules
└── firebase-blueprint.json
```

## Prérequis

- Flutter SDK ≥ 3.0.0
- Firebase project configuré
- Google Maps API key

## Démarrage rapide

```bash
flutter pub get
flutterfire configure   # connecte votre projet Firebase
flutter run
```

## Variables à configurer

1. `android/app/google-services.json` — télécharger depuis Firebase Console
2. `ios/Runner/GoogleService-Info.plist` — idem pour iOS
3. Dans `lib/services/geolocation_service.dart` : remplacer `YOUR_GOOGLE_MAPS_KEY`

## Stack technique

| Couche | Technologie |
|--------|-------------|
| State management | Riverpod 2.x |
| Backend | Firebase (Auth, Firestore, Storage, FCM) |
| Cartes | Google Maps Flutter |
| Auth | Firebase Phone Auth (OTP SMS) |
| Notifications push | Firebase Cloud Messaging |

## Rôles utilisateur

- **Client** : publie une demande, reçoit des offres, accepte un Maâlem
- **Artisan (Maâlem)** : voit les demandes en temps réel, soumet un prix
- **Admin** : supervise et valide les profils artisans
