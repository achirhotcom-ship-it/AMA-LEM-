import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color darkNavy = Color(0xFF0B0F19);
  static const Color cardNavy = Color(0xFF161F30);
  static const Color borderNavy = Color(0xFF223147);
  static const Color moroccanRed = Color(0xFFC1272D); // Rouge drapeau marocain
  static const Color moroccanGreen = Color(0xFF1E824C); // Vert impérial
  static const Color accentGold = Color(0xFFE0A025);
  static const Color textWhite = Color(0xFFF1F5F9);

  static ThemeData get darkNavyTheme {
    return ThemeData.dark().copyWith(
      scaffoldBackgroundColor: darkNavy,
      cardColor: cardNavy,
      primaryColor: moroccanRed,
      colorScheme: const ColorScheme.dark(
        primary: moroccanRed,
        secondary: moroccanGreen,
        background: darkNavy,
        surface: cardNavy,
      ),
      textTheme: GoogleFonts.spaceGroteskTextTheme().copyWith(
        bodyLarge: GoogleFonts.inter(color: textWhite),
        bodyMedium: GoogleFonts.inter(color: textWhite.withOpacity(0.8)),
      ),
      cardTheme: CardTheme(
        color: cardNavy,
        elevation: 8,
        shape: RoundedRectangleBorder(
          side: const BorderSide(color: borderNavy, width: 1.2),
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: cardNavy,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: borderNavy),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: borderNavy),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: moroccanGreen,
          foregroundColor: Colors.white,
          elevation: 4,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}