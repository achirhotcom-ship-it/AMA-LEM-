import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'core/theme/app_theme.dart';
import 'providers/auth_provider.dart';
import 'screens/auth/phone_auth_screen.dart';
import 'screens/client/client_home_screen.dart';
import 'screens/artisan/artisan_home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  
  runApp(
    const ProviderScope(
      child: AmaalemApp(),
    ),
  );
}

class AmaalemApp extends ConsumerWidget {
  const AmaalemApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);

    return MaterialApp(
      title: 'AMAÂLEM',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkNavyTheme,
      home: authState.when(
        data: (user) {
          if (user == null) {
            return const PhoneAuthScreen();
          }
          // Routage dynamique basé sur le rôle utilisateur (dans document Firestore)
          return ref.watch(currentUserProfileProvider).when(
            data: (profile) {
              if (profile == null) return const PhoneAuthScreen();
              if (profile.role == 'artisan') {
                return const ArtisanHomeScreen();
              }
              return const ClientHomeScreen();
            },
            loading: () => const Scaffold(
              body: Center(child: CircularProgressIndicator(color: AppTheme.moroccanGreen)),
            ),
            error: (err, _) => Scaffold(
              body: Center(child: Text("Erreur de profil: $err")),
            ),
          );
        },
        loading: () => const Scaffold(
          body: Center(child: CircularProgressIndicator(color: AppTheme.moroccanGreen)),
        ),
        error: (err, _) => Scaffold(
          body: Center(child: Text("Erreur d'authentification: $err")),
        ),
      ),
    );
  }
}