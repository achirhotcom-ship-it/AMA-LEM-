import 'package:cloud_firestore/cloud_firestore.dart';

class ArtisanModel {
  final String uid;
  final String name;
  final String businessName;
  final String category; // 'plomberie', 'electricite', etc.
  final String city;
  final bool verified;
  final double rating;
  final int reviewsCount;
  final String availability; // 'immediate' | 'busy' | 'away'
  final double? latitude;
  final double? longitude;
  final String? cinNumber;

  ArtisanModel({
    required this.uid,
    required this.name,
    required this.businessName,
    required this.category,
    required this.city,
    this.verified = false,
    this.rating = 5.0,
    this.reviewsCount = 0,
    this.availability = 'immediate',
    this.latitude,
    this.longitude,
    this.cinNumber,
  });

  factory ArtisanModel.fromMap(Map<String, dynamic> map, String id) {
    return ArtisanModel(
      uid: id,
      name: map['name'] ?? '',
      businessName: map['businessName'] ?? '',
      category: map['category'] ?? '',
      city: map['city'] ?? 'Casablanca',
      verified: map['verified'] ?? false,
      rating: (map['rating'] as num?)?.toDouble() ?? 5.0,
      reviewsCount: map['reviewsCount'] ?? 0,
      availability: map['availability'] ?? 'immediate',
      latitude: (map['latitude'] as num?)?.toDouble(),
      longitude: (map['longitude'] as num?)?.toDouble(),
      cinNumber: map['cinNumber'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'businessName': businessName,
      'category': category,
      'city': city,
      'verified': verified,
      'rating': rating,
      'reviewsCount': reviewsCount,
      'availability': availability,
      'latitude': latitude,
      'longitude': longitude,
      'cinNumber': cinNumber,
    };
  }
}