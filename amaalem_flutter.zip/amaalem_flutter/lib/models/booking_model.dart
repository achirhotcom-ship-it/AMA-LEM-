import 'package:cloud_firestore/cloud_firestore.dart';

class BookingModel {
  final String id;
  final String requestId;
  final String clientId;
  final String artisanId;
  final double price;
  final String status; // 'confirmed' | 'arrived' | 'inprogress' | 'completed'
  final String otpVerification; // Code unique marocain (4 chiffres)
  final DateTime dateCreated;

  BookingModel({
    required this.id,
    required this.requestId,
    required this.clientId,
    required this.artisanId,
    required this.price,
    required this.status,
    required this.otpVerification,
    required this.dateCreated,
  });

  factory BookingModel.fromMap(Map<String, dynamic> map, String docId) {
    return BookingModel(
      id: docId,
      requestId: map['requestId'] ?? '',
      clientId: map['clientId'] ?? '',
      artisanId: map['artisanId'] ?? '',
      price: (map['price'] as num?)?.toDouble() ?? 0.0,
      status: map['status'] ?? 'confirmed',
      otpVerification: map['otpVerification'] ?? '',
      dateCreated: (map['dateCreated'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'requestId': requestId,
      'clientId': clientId,
      'artisanId': artisanId,
      'price': price,
      'status': status,
      'otpVerification': otpVerification,
      'dateCreated': Timestamp.fromDate(dateCreated),
    };
  }
}