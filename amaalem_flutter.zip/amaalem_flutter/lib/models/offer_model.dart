import 'package:cloud_firestore/cloud_firestore.dart';

class OfferModel {
  final String id;
  final String requestId;
  final String artisanId;
  final String artisanName;
  final double priceProposed;
  final int etaMinutes;
  final String status; // 'pending' | 'accepted' | 'declined'
  final DateTime dateCreated;

  OfferModel({
    required this.id,
    required this.requestId,
    required this.artisanId,
    required this.artisanName,
    required this.priceProposed,
    required this.etaMinutes,
    required this.status,
    required this.dateCreated,
  });

  factory OfferModel.fromMap(Map<String, dynamic> map, String docId) {
    return OfferModel(
      id: docId,
      requestId: map['requestId'] ?? '',
      artisanId: map['artisanId'] ?? '',
      artisanName: map['artisanName'] ?? '',
      priceProposed: (map['priceProposed'] as num?)?.toDouble() ?? 0.0,
      etaMinutes: map['etaMinutes'] ?? 15,
      status: map['status'] ?? 'pending',
      dateCreated: (map['dateCreated'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'requestId': requestId,
      'artisanId': artisanId,
      'artisanName': artisanName,
      'priceProposed': priceProposed,
      'etaMinutes': etaMinutes,
      'status': status,
      'dateCreated': Timestamp.fromDate(dateCreated),
    };
  }
}