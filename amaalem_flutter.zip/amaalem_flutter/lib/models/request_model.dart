import 'package:cloud_firestore/cloud_firestore.dart';

class RequestModel {
  final String id;
  final String consumerId;
  final String title;
  final String description;
  final String category;
  final double budgetProposed;
  final bool urgent;
  final String status; // 'searching', 'negotiating', 'accepted', 'completed'
  final String? voiceNoteUrl;
  final String? photoUrl;
  final double latitude;
  final double longitude;
  final DateTime dateCreated;

  RequestModel({
    required this.id,
    required this.consumerId,
    required this.title,
    required this.description,
    required this.category,
    required this.budgetProposed,
    this.urgent = false,
    required this.status,
    this.voiceNoteUrl,
    this.photoUrl,
    required this.latitude,
    required this.longitude,
    required this.dateCreated,
  });

  factory RequestModel.fromMap(Map<String, dynamic> data, String docId) {
    return RequestModel(
      id: docId,
      consumerId: data['consumerId'] ?? '',
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      category: data['category'] ?? '',
      budgetProposed: (data['budgetProposed'] as num?)?.toDouble() ?? 0.0,
      urgent: data['urgent'] ?? false,
      status: data['status'] ?? 'searching',
      voiceNoteUrl: data['voiceNoteUrl'],
      photoUrl: data['photoUrl'],
      latitude: (data['latitude'] as num?)?.toDouble() ?? 33.5731,
      longitude: (data['longitude'] as num?)?.toDouble() ?? -7.5898,
      dateCreated: (data['dateCreated'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'consumerId': consumerId,
      'title': title,
      'description': description,
      'category': category,
      'budgetProposed': budgetProposed,
      'urgent': urgent,
      'status': status,
      'voiceNoteUrl': voiceNoteUrl,
      'photoUrl': photoUrl,
      'latitude': latitude,
      'longitude': longitude,
      'dateCreated': Timestamp.fromDate(dateCreated),
    };
  }
}