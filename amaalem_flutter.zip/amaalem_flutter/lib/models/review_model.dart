import 'package:cloud_firestore/cloud_firestore.dart';

class ReviewModel {
  final String id;
  final String bookingId;
  final String artisanId;
  final String reviewerName;
  final double rating;
  final String comment;
  final DateTime dateCreated;

  ReviewModel({
    required this.id,
    required this.bookingId,
    required this.artisanId,
    required this.reviewerName,
    required this.rating,
    required this.comment,
    required this.dateCreated,
  });

  factory ReviewModel.fromMap(Map<String, dynamic> map, String docId) {
    return ReviewModel(
      id: docId,
      bookingId: map['bookingId'] ?? '',
      artisanId: map['artisanId'] ?? '',
      reviewerName: map['reviewerName'] ?? '',
      rating: (map['rating'] as num?)?.toDouble() ?? 5.0,
      comment: map['comment'] ?? '',
      dateCreated: (map['dateCreated'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'bookingId': bookingId,
      'artisanId': artisanId,
      'reviewerName': reviewerName,
      'rating': rating,
      'comment': comment,
      'dateCreated': Timestamp.fromDate(dateCreated),
    };
  }
}