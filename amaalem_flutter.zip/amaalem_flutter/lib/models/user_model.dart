import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String name;
  final String phone;
  final String role; // 'consumer' | 'artisan' | 'admin'
  final String city;
  final DateTime dateJoined;

  UserModel({
    required this.uid,
    required this.name,
    required this.phone,
    required this.role,
    required this.city,
    required this.dateJoined,
  });

  factory UserModel.fromMap(Map<String, dynamic> data, String id) {
    return UserModel(
      uid: id,
      name: data['name'] ?? '',
      phone: data['phone'] ?? '',
      role: data['role'] ?? 'consumer',
      city: data['city'] ?? 'Casablanca',
      dateJoined: (data['dateJoined'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phone': phone,
      'role': role,
      'city': city,
      'dateJoined': Timestamp.fromDate(dateJoined),
    };
  }
}