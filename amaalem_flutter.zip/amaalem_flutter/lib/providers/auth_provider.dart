import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';
import '../models/user_model.dart';

final authServiceRef = Provider<AuthService>((ref) => AuthService());

// Écoute des états d'authentification Firebase brute
final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(authServiceRef).authStateChanges;
});

// Profil utilisateur complet synchronisé avec Firestore
final currentUserProfileProvider = FutureProvider<UserModel?>((ref) async {
  final rawUser = ref.watch(authStateProvider).value;
  if (rawUser == null) return null;
  return ref.watch(authServiceRef).fetchUser(rawUser.uid);
});