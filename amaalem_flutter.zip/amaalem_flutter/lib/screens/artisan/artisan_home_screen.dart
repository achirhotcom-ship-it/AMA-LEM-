import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class ArtisanHomeScreen extends StatefulWidget {
  const ArtisanHomeScreen({super.key});

  @override
  State<ArtisanHomeScreen> createState() => _ArtisanHomeScreenState();
}

class _ArtisanHomeScreenState extends State<ArtisanHomeScreen> {
  bool _isOnline = true;
  double _totalEarnings = 4320.00; // DH sans commission

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.darkNavy,
      appBar: AppBar(
        title: const Text("Maâlem Dashboard"),
        backgroundColor: AppTheme.cardNavy,
        actions: [
          Row(
            children: [
              Text(_isOnline ? "EN LIGNE" : "HORS LIGNE", style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
              Switch(
                value: _isOnline,
                activeColor: AppTheme.moroccanGreen,
                onChanged: (val) {
                  setState(() => _isOnline = val);
                },
              ),
            ],
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Indicateur de performance
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    const Text("Vos gains totaux garantis (0 % de commission)", style: TextStyle(color: Colors.grey, fontSize: 13)),
                    const SizedBox(height: 8),
                    Text(
                      "\$_totalEarnings DH",
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppTheme.moroccanGreen),
                    ),
                    const SizedBox(height: 12),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            Text("Note moyenne", style: TextStyle(color: Colors.grey, fontSize: 11)),
                            Text("4.9/5", style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.accentGold)),
                          ],
                        ),
                        Column(
                          children: [
                            Text("Missions résolues", style: TextStyle(color: Colors.grey, fontSize: 11)),
                            Text("24", style: TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              "Demandes d'interventions directes à proximité (SOS)",
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            
            // Item d'appel d'offre inDrive à enchérir
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.between,
                      children: [
                        const Text("FUITE D'EAU ROBINET - Maârif", style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(color: AppTheme.moroccanRed.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                          child: const Text("SOS URGENT", style: TextStyle(color: AppTheme.moroccanRed, fontSize: 9, fontWeight: FontWeight.bold)),
                        )
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text("Sujet: Robinet d'eau de cuisine usé, forte fuite depuis 30 minutes. Le client propose 150 DH de prix de départ.", style: TextStyle(color: Colors.grey, fontSize: 12)),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              // Contre-proposer un tarif plus adéquat
                            },
                            child: const Text("Contre-proposer 180 DH"),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              // Accepter le prix client
                            },
                            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.moroccanGreen),
                            child: const Text("Accepter 150 DH"),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}