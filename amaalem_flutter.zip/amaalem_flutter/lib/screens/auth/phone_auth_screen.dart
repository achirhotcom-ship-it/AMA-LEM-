import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/auth_provider.dart';

class PhoneAuthScreen extends ConsumerStatefulWidget {
  const PhoneAuthScreen({super.key});

  @override
  ConsumerState<PhoneAuthScreen> createState() => _PhoneAuthScreenState();
}

class _PhoneAuthScreenState extends ConsumerState<PhoneAuthScreen> {
  final _phoneController = TextEditingController();
  final _codeController = TextEditingController();
  final _nameController = TextEditingController();

  String _verificationId = '';
  bool _otpSent = false;
  String _selectedRole = 'consumer'; // 'consumer' ou 'artisan'
  String _selectedCity = 'Casablanca';

  void _triggerSMS() async {
    final phone = _phoneController.text.trim();
    if (phone.isEmpty) return;

    await ref.read(authServiceRef).sendOTPMorocco(
      phone,
      onCodeSent: (id) {
        setState(() {
          _verificationId = id;
          _otpSent = true;
        });
      },
      onFailed: (err) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
      },
    );
  }

  void _confirmCode() async {
    final code = _codeController.text.trim();
    if (code.isEmpty) return;

    try {
      await ref.read(authServiceRef).verifyOTPAndRegister(
        verificationId: _verificationId,
        smsCode: code,
        name: _nameController.text.trim(),
        role: _selectedRole,
        city: _selectedCity,
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Échec: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppTheme.darkNavy, Color(0xFF161F30)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      "ARTISAN DIRECT",
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppTheme.textWhite),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Interventions géolocalisées en direct du Maroc, sans commission",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                    const SizedBox(height: 24),
                    if (!_otpSent) ...[
                      TextField(
                        controller: _nameController,
                        decoration: const InputDecoration(labelText: "Votre Nom / Prénom"),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(
                          labelText: "Numéro de téléphone (+212...)",
                          prefixIcon: Icon(Icons.phone),
                        ),
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: _selectedRole,
                        dropdownColor: AppTheme.cardNavy,
                        decoration: const InputDecoration(labelText: "Sélectionnez votre rôle"),
                        items: const [
                          DropdownMenuItem(value: 'consumer', child: Text("Je cherche un Maâlem (Client)")),
                          DropdownMenuItem(value: 'artisan', child: Text("Proposer mes services (Artisan Pro)")),
                        ],
                        onChanged: (val) => setState(() => _selectedRole = val!),
                      ),
                      const SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: _triggerSMS,
                        style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                        child: const Text("Recevoir le code OTP par SMS"),
                      ),
                    ] else ...[
                      const Text("Code de confirmation envoyé avec succès !"),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _codeController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: "Saisir le Code OTP reçu"),
                      ),
                      const SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: _confirmCode,
                        style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                        child: const Text("Vérifier & Accéder à la plateforme"),
                      ),
                    ]
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}