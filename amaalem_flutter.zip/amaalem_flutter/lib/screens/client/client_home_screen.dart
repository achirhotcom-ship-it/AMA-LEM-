import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../core/theme/app_theme.dart';

class ClientHomeScreen extends StatefulWidget {
  const ClientHomeScreen({super.key});

  @override
  State<ClientHomeScreen> createState() => _ClientHomeScreenState();
}

class _ClientHomeScreenState extends State<ClientHomeScreen> {
  late GoogleMapController _mapController;
  final LatLng _moroccanCenter = const LatLng(33.5731, -7.5898); // Casablanca

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("AMAÂLEM (Client)"),
        backgroundColor: AppTheme.cardNavy,
      ),
      body: Stack(
        children: [
          // Écran Carte interactive pour tracker l'arrivée
          GoogleMap(
            initialCameraPosition: CameraPosition(target: _moroccanCenter, zoom: 14),
            onMapCreated: (controller) => _mapController = controller,
            myLocationEnabled: true,
            zoomControlsEnabled: false,
          ),
          
          // Formulaire d'intervention inDrive instantané
          Positioned(
            left: 16,
            right: 16,
            bottom: 30,
            child: Card(
              color: AppTheme.cardNavy.withOpacity(0.95),
              child: Padding(
                padding: const EdgeInsets.all(18.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      "Nouveau Dépannage en direct",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      decoration: InputDecoration(
                        hintText: "Quel est le problème ? (Ex : Fuite d'eau)",
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              hintText: "Votre tarif proposé (DH)",
                              hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: const Icon(Icons.mic, color: AppTheme.moroccanRed),
                          onPressed: () {
                            // Enregistrement vocal
                          },
                          tooltip: "Ajouter un mémo vocal explicatif",
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: () {
                        // Publier le lead inDrive
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: AppTheme.moroccanGreen),
                      child: const Text("Diffuser aux Maâlems à proximité"),
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}