import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Envoi du SMS OTP
  Future<void> sendOTPMorocco(
    String phoneNumber, {
    required Function(String verificationId) onCodeSent,
    required Function(String error) onFailed,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        onFailed(e.message ?? 'Échec lors de l\'envoi du SMS.');
      },
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  // Vérification de l'OTP et création de compte (Rôle préservé)
  Future<UserCredential> verifyOTPAndRegister({
    required String verificationId,
    required String smsCode,
    required String name,
    required String role,
    required String city,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    final userCred = await _auth.signInWithCredential(credential);

    if (userCred.user != null) {
      final uid = userCred.user!.uid;
      final doc = await _db.collection('users').doc(uid).get();

      if (!doc.exists) {
        final profile = UserModel(
          uid: uid,
          name: name,
          phone: userCred.user!.phoneNumber ?? '',
          role: role,
          city: city,
          dateJoined: DateTime.now(),
        );
        await _db.collection('users').doc(uid).set(profile.toMap());

        // Configuration secondaire si Artisan professionnel
        if (role == 'artisan') {
          await _db.collection('artisans').doc(uid).set({
            'name': name,
            'businessName': 'Atelier $name',
            'category': 'plomberie',
            'city': city,
            'verified': false,
            'rating': 5.0,
            'reviewsCount': 0,
            'availability': 'immediate',
            'latitude': 33.5731,
            'longitude': -7.5898,
          });
        }
      }
    }
    return userCred;
  }

  Future<UserModel?> fetchUser(String uid) async {
    final snap = await _db.collection('users').doc(uid).get();
    if (snap.exists && snap.data() != null) {
      return UserModel.fromMap(snap.data()!, snap.id);
    }
    return null;
  }

  Future<void> logout() async {
    await _auth.signOut();
  }
}