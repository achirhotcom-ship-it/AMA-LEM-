import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/request_model.dart';
import '../models/offer_model.dart';
import '../models/booking_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Création d'appel d'offres
  Future<void> launchJobRequest(RequestModel req) async {
    await _db.collection('requests').doc(req.id).set(req.toMap());
  }

  // Écouter les propositions d'artisans (pour le Client)
  Stream<List<OfferModel>> streamOffersForRequest(String requestId) {
    return _db.collection('offers')
        .where('requestId', isEqualTo: requestId)
        .orderBy('dateCreated', descending: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => OfferModel.fromMap(doc.data(), doc.id))
            .toList());
  }

  // Soumettre un BID de prix (pour l'Artisan)
  Future<void> submitBidOffer(OfferModel offer) async {
    await _db.collection('offers').doc(offer.id).set(offer.toMap());
    // Lever letat vers la négociation active
    await _db.collection('requests').doc(offer.requestId).update({
      'status': 'negotiating',
    });
  }

  // Clôturer l'accord (Création d'un booking valide avec OTP de sécurité)
  Future<void> validateOfferAndLockBooking(OfferModel offer, String clientId) async {
    final batch = _db.batch();

    // 1. Accepter l'offre
    final offerRef = _db.collection('offers').doc(offer.id);
    batch.update(offerRef, {'status': 'accepted'});

    // 2. Mutaer la demande
    final reqRef = _db.collection('requests').doc(offer.requestId);
    batch.update(reqRef, {'status': 'accepted'});

    // 3. Créer la réservation ferme
    final bookingId = 'bk_\${DateTime.now().millisecondsSinceEpoch}';
    final booking = BookingModel(
      id: bookingId,
      requestId: offer.requestId,
      clientId: clientId,
      artisanId: offer.artisanId,
      price: offer.priceProposed,
      status: 'confirmed',
      otpVerification: (1000 + (DateTime.now().microsecond % 9000)).toString(),
      dateCreated: DateTime.now(),
    );

    final bookingRef = _db.collection('bookings').doc(bookingId);
    batch.set(bookingRef, booking.toMap());

    await batch.commit();
  }
}