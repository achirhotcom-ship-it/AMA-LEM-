import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class GeolocationService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Consentement et coordonnées initiales gps
  Future<Position> determineCurrentPosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Veuillez activer votre GPS de smartphone.');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Accès GPS refusé.');
      }
    }
    
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  // Flux de géolocalisation continue (Envoi à Firestore toutes les 10s si actif)
  void initializeLiveArtisanTracking(String artisanId) {
    const LocationSettings settings = LocationSettings(
      accuracy: LocationAccuracy.bestForNavigation,
      distanceFilter: 15, // Mises à jour tous les 15m de déplacement
    );

    Geolocator.getPositionStream(locationSettings: settings).listen((Position pos) {
      _db.collection('artisans').doc(artisanId).update({
        'latitude': pos.latitude,
        'longitude': pos.longitude,
        'lastUpdate': FieldValue.serverTimestamp(),
      });
    });
  }
}