import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotification = FlutterLocalNotificationsPlugin();

  Future<void> initPushEngine() async {
    // Étape 1 : Demande de permissions
    await _fcm.requestPermission(
      alert: true,
      sound: true,
      badge: true,
    );

    // Étape 2 : Réception du token unique
    String? token = await _fcm.getToken();
    print("FCM Device Token marocain: $token");

    // S'abonner aux services d'urgence locaux
    await _fcm.subscribeToTopic('morocco_leads_plumbing');

    // Étape 3 : Configurer les alertes visuelles locales si premier plan
    const AndroidInitializationSettings androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings init = InitializationSettings(android: androidInit);
    await _localNotification.initialize(init);

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      final notif = message.notification;
      if (notif != null) {
        _localNotification.show(
          notif.hashCode,
          notif.title,
          notif.body,
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'high_urgency_leads',
              'Chantiers d\\\'Artisanat SOS',
              importance: Importance.max,
              priority: Priority.high,
            ),
          ),
        );
      }
    });
  }
}