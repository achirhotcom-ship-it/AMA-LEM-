import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class AmaalemLogo extends StatelessWidget {
  final double size;
  const AmaalemLogo({super.key, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.goldPrimary, AppTheme.goldLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(size * 0.2),
      ),
      child: Center(
        child: Text(
          'M',
          style: TextStyle(
            color: AppTheme.navyDark,
            fontSize: size * 0.55,
            fontWeight: FontWeight.w900,
            letterSpacing: -1,
          ),
        ),
      ),
    );
  }
}
